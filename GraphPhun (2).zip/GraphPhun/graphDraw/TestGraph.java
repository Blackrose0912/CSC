package graphDraw;
import graphTypes.*;

import java.util.ArrayList;

/**
 * TestGraph.java -- class to execute tests and display generic points, segments, and graphs
 *    for data in a unit-square
 *
 * A. Thall
 * CSC 240 W12
 * 2/25/2012
 */


import java.awt.*;
import javax.swing.*;

/**
 * @author A. Thall
 * 11/7/17:  added JFrame setLocationRelativeTo(null) to automatically center window
 */
public class TestGraph extends JFrame
{
    Renderer drawing;
    
    /**
     * instance constructor creates JFrame for rendering
     * -- called in main()
     */
    public TestGraph() {
        
        Container content = this.getContentPane();  // get content pane
        content.setLayout(new BorderLayout());      // set its layout
        drawing = new Renderer(this);  // Create a drawing window in the pain
        content.add(drawing, BorderLayout.CENTER);  // center expands
        
        this.setTitle("Swell Graph Renderer");
        this.pack();             // finalize window layout
    }
    
    int choice = 0;
    GraphADT mat = null;
    final int NUMCHOICES = 1;
    
    public void createAndShowPoints() {

    	drawing.clearPoints();
    	drawing.clearEdges();

    	if (choice == 0) {
    		// 0:  create complete WtAdjMatrixGraph
    		mat = new AdjMatrixGraph(10);
    		mat.bfsGraph();
    		drawing.addGraph(mat);
    		choice = (choice + 1) % 1;
    		this.setTitle("Swell Graph Renderer: the graph!");
    	}
    	else if (choice == 1) {
/*
    		mat = new AdjMatrixGraph(20);
    		for (int i = 0; i < mat.numVerts() - 1; i++)
    			for (int j = i+1; j < mat.numVerts(); j += 1)
    				mat.addEdge(i, j);
    		drawing.addGraph(mat);
    		choice = (choice + 1) % 1;
    		this.setTitle("Swell Graph Renderer: AdjMatrixGraph!");
    		*/
    	}
    	else if (choice == 2) {
    		/*
    		 * mat = mat.dfsGraph();
    		 * drawing.addGRaph(mat);
    		 * choice = (choice + 1) % NUMCHOICES;
    		 * this.setTitle("Swell Graph Renderer: DFS Graph");
    		 */
    	}
    	

    }

    /**
     * driver method for min-point-distance finder
     * @param args -- optional number of points > 0
     */
    public static void main(String []args) {
        
        JFrame window = new TestGraph();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
        window.setLocationRelativeTo(null);
        
        ((TestGraph) window).createAndShowPoints();
    }
}