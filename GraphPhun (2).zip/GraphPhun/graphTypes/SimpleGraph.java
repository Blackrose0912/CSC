package graphTypes;
/**
 * SimpleGraph.java -- a simple graph class with n vertices and 1 edge between vertex 0 and 1
 * Extends GraphADT
 * Project; GraphPhun
 * A. Thall
 * CSC 230 F17
 * 11/8/17
 */
//
//arraylist of an arraylist of integers

import java.util.ArrayList;
import java.util.Random;
import java.util.Iterator;

import graphDraw.*;


/**
 * A simple class to test graphDraw application code and demonstrate its use
 *
 */
public class SimpleGraph extends GraphADT {

	// since only have a single edge, store v0 and v1 names in single variables
	private int pt0, pt1;
	/**
	 * 
	 */
	public SimpleGraph() {
		// TODO Auto-generated constructor stub
		super(2);
		nEdges = 1;
		pt0 = 0;
		pt1 = 1;
	}

	public SimpleGraph(int nVerts) {
		super(nVerts);
		nEdges = 1;
		pt0 = 0;
		pt1 = 1;
	}
	
	/**
	 * @param nVerts
	 */
	public SimpleGraph(int nVerts, ArrayList<Point> coords) {//needed for heap
		super(nVerts, coords); //so parent class knows how many vertices there are
		if (coords == null) {
			super.coords = new ArrayList<Point>();
			super.coords.add(new Point());
			super.coords.add(new Point());
		}
		else if (coords.size() == 0) {
			super.coords.add(new Point());
			super.coords.add(new Point());
		}
		else if (coords.size() == 1)
			super.coords.add(new Point());
		nEdges = 1;
		pt0 = 0;
		pt1 = 0;
	}
	
	
	public String toString() {//doing this so you can print out the matrix that's storing the values
	
		String retval = "Graph with " + nVerts + " vertices\n"
								+ "and 1 edge\n";
		return retval;
	}
	
		
	/* (non-Javadoc)
	 * @see GraphADT#addVertex()
	 */
	@Override
	public int addVertex() {
		//has to add another arraylist at the end
		//mat.add(new ArrayList<Double>());
		//set all to 0
		
		return 0;
	}

	/* (non-Javadoc)
	 * @see GraphADT#addEdge(int, int)
	 */
	@Override
	public void addEdge(int v0, int v1) { }

	/* (non-Javadoc)
	 * @see GraphADT#addRandomEdge()
	 */
	@Override
	public void addRandomEdge() {
		// TODO Auto-generated method stub
	}

	/* (non-Javadoc)
	 * @see GraphADT#hasEdge(int, int)
	 */
	@Override
	public boolean hasEdge(int v0, int v1) {
		
		
		return (v0 == 0 && v1 == 1) || (v0 == 1 && v1 == 0);
	}

	/* (non-Javadoc)
	 * @see GraphADT#hasPath(int, int)
	 */
	@Override
	public boolean hasPath(int v0, int v1) {
		
		return (v0 == 0 && v1 == 1) || (v0 == 1 && v1 == 0);
	}

	/* (non-Javadoc)
	 * @see GraphADT#connected()
	 */
	@Override
	public boolean connected() {
		return nVerts == 2 ? true : false;
	}

	public boolean isIsomorphic(GraphADT g) {
		if (g.numVerts() == nVerts && g.numEdges() == 1)
			return true;
		else
			return false;
	};
	public GraphADT dfsGraph() {
		return this;
	}
	
	public GraphADT bfsGraph() {
		return this;
	}
	
	public Iterable<Segment> segmentIterable() {
		
		ArrayList<Segment> segments = new ArrayList<Segment>();
		
		segments.add(new Segment(coords.get(0), coords.get(1)));

		return segments;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GraphADT g = new SimpleGraph(20);
		System.out.println("Created new graph: " + g);
	}

}
