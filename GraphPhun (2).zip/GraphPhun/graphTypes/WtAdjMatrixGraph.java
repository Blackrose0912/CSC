package graphTypes;
/**
 * WtAdjMatrixGraph.java
 * 
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import graphDraw.*;

/**
 * A extended class of AdjMatrixGraph for storing weighted undirected graphs
 *
 */
public class WtAdjMatrixGraph extends AdjMatrixGraph {

}
