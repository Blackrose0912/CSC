/**
 * 
 */
package graphTypes;

import java.util.ArrayList;

import graphDraw.Point;
import graphDraw.Segment;

/**
 * @author Gannon S. Clifford
 *
 */
public class AdjMatrixGraph extends GraphADT {

	/**
	 * 
	 */
	boolean [][] adjMatrix;
	ArrayList<Segment> segments;
	ArrayList<Point> coords;
	Point [] points;
	
	public AdjMatrixGraph() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param nVerts
	 */
	public AdjMatrixGraph(int nVerts) {
		super(nVerts);
		this.coords = super.coords;
		segments = new ArrayList<Segment>();
		adjMatrix = new boolean [nVerts][nVerts];
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param nVerts
	 * @param coords
	 */
	public AdjMatrixGraph(int nVerts, ArrayList<Point> coords) {
		super(nVerts, coords);
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see graphTypes.GraphADT#segmentIterable()
	 */
	@Override
	public Iterable<Segment> segmentIterable() {
		// TODO Auto-generated method stub
		ArrayList <Segment> segments = new ArrayList<Segment>();
		for(int v1 = 0; v1 < numVerts(); v1++)
			for(int v2 = 0; v2 < adjMatrix[v1].length; v2++)
				if(adjMatrix[v1][v2] == true)
				segments.add(new Segment(coords.get(v1), coords.get(v2)));
		return segments;
	}

	/* (non-Javadoc)
	 * @see graphTypes.GraphADT#addVertex()
	 */
	@Override
	public int addVertex() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see graphTypes.GraphADT#addEdge(int, int)
	 */
	@Override
	public void addEdge(int v0, int v1) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see graphTypes.GraphADT#addRandomEdge()
	 */
	@Override
	public void addRandomEdge() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see graphTypes.GraphADT#hasEdge(int, int)
	 */
	@Override
	public boolean hasEdge(int v0, int v1) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see graphTypes.GraphADT#hasPath(int, int)
	 */
	@Override
	public boolean hasPath(int v0, int v1) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see graphTypes.GraphADT#connected()
	 */
	@Override
	public boolean connected() {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see graphTypes.GraphADT#isIsomorphic(graphTypes.GraphADT)
	 */
	@Override
	public boolean isIsomorphic(GraphADT g) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see graphTypes.GraphADT#dfsGraph()
	 */
	@Override
	public GraphADT dfsGraph() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see graphTypes.GraphADT#bfsGraph()
	 */
	@Override
	public GraphADT bfsGraph() {
		super.visited = new ArrayList<Point>();
		Point p = coords.get(0);
		super.visited.add(p);
		Point current = coords.get(1);
		
		while(super.visited.size() !=  coords.size()) {
			
			for(int i = 0; i < coords.size(); i++) {
				
				if(p.dist(current) > p.dist(coords.get(1))
					&& !coords.get(i).equals(current)
					&& !coords.get(i).equals(p)
					&& !super.visited.contains(coords.get(i))){
					current = coords.get(i);
				}
		
			}
		
		
		adjMatrix[coords.indexOf(p)][coords.indexOf(current)] = true;
		super.visited.add(current);
		p = current;
		
		for (int i = 0; i < coords.size(); i++) {
			if(!visited.contains(coords.get(i)) && !coords.get(i).equals(p)) {
				current = coords.get(i);
			}
		}
		
		}
	
			return this;
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
